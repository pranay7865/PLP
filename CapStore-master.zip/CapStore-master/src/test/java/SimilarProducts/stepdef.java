package SimilarProducts;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	@Given("^Open products page for a particular product$")
	public void open_products_page_for_a_particular_product() throws Throwable {
	   
	}

	@When("^A product is searched$")
	public void a_product_is_searched() throws Throwable {
	   
	}

	@Then("^Display similar products$")
	public void display_similar_products() throws Throwable {
	    
	}
}