export interface Icustomer
{
    CustomerId: number,
    CustomerName:string,
    CutomerMob: number,
    Customercity:string
}