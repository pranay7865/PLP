import { Component, OnInit } from '@angular/core';
import { Iproduct } from './Product';
import { WishListService } from 'src/wish-list.service';

@Component({
  selector: 'app-product-wish-list',
  templateUrl: './product-wish-list.component.html',
  styleUrls: ['./product-wish-list.component.css']
})
export class ProductWishListComponent implements OnInit {

  wishList:Iproduct[]
productAdded:boolean = false;
constructor(private service:WishListService) { }


  ngOnInit() {
    // this.service.getproducts().subscribe(d=>this.products=d);
    this.service.getproducts();
  }
  send(b){
   for(let p of this.service.wishList){
     if(b.ProductId==p.ProductId)
     {
      alert('already submited');
      this.productAdded =true;
     }

   }
   if(!this.productAdded){
   this.service.wishList.push({   
    ProductId:b.ProductId,
    ProductName:b.ProductName,
    ProductPrice:b.ProductPrice });
   }
  else
  this.productAdded =false;
 }

}
