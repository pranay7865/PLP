export interface Iproduct
{
    ProductId: number,
    ProductName:string,
    ProductPrice: number
}