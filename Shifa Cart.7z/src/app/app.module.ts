import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {Route, RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductWishListComponent } from './product-wish-list/product-wish-list.component';
import { WishListdataComponent } from './wish-listdata/wish-listdata.component';


const routes:Route[]=[

  {
    path:'view',
    component:WishListdataComponent
  }
];
@NgModule({
  declarations: [
    AppComponent,
    ProductWishListComponent,
    WishListdataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot(routes)

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
