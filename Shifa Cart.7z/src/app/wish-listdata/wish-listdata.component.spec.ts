import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WishListdataComponent } from './wish-listdata.component';

describe('WishListdataComponent', () => {
  let component: WishListdataComponent;
  let fixture: ComponentFixture<WishListdataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WishListdataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WishListdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
