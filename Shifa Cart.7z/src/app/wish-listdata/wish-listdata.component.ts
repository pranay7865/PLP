import { Component, OnInit } from '@angular/core';
import { WishListService } from 'src/wish-list.service';
import { Iproduct } from '../product-wish-list/Product';

@Component({
  selector: 'app-wish-listdata',
  templateUrl: './wish-listdata.component.html',
  styleUrls: ['./wish-listdata.component.css']
})
export class WishListdataComponent implements OnInit {

  constructor(private service:WishListService) { }

  ngOnInit() {

  }
  delete(pro : Iproduct)
  {
    let newList = this.service.wishList.filter(data => data.ProductId !=pro.ProductId);
    this.service.wishList = newList;
  }


    
  }


