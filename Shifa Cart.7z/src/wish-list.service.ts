import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Iproduct } from './app/product-wish-list/Product';


@Injectable({
  providedIn: 'root'
})
export class WishListService {
  url:string='assets/Product.json';
  wishList:Iproduct[] = [];
  productList: Iproduct[];
  constructor(private http :HttpClient) { }

  getproducts():any{
    this.http.get<Iproduct[]>(this.url).subscribe(res=>{
      this.productList=res;
    })
}
}
