package com.capstore.dao;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.capstore.model.FeedbackCommon;

@Repository
public interface FeedbackRepository extends CrudRepository <FeedbackCommon, Long>{}
