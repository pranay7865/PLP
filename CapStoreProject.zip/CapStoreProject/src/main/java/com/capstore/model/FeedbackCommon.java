package com.capstore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="Feedback_Common")
public class FeedbackCommon 
{
	
	@Id
	@Column(length=10)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long product_id;
	
	@Column(length=10)
    private long merchant_id;
	
	@Column(length=10)
    private long product_rating;
	
	@Column(length=250)
    private String feedback;
	
	@Column(length=20)
    private String status;

	public long getProduct_id() {
		return product_id;
	}

	public void setProduct_id(long product_id) {
		this.product_id = product_id;
	}

	public long getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(long merchant_id) {
		this.merchant_id = merchant_id;
	}

	public long getProduct_rating() {
		return product_rating;
	}

	public void setProduct_rating(long product_rating) {
		this.product_rating = product_rating;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "FeedbackCommon [product_id=" + product_id + ", merchant_id=" + merchant_id + ", product_rating="
				+ product_rating + ", feedback=" + feedback + ", status=" + status + "]";
	}
	
	

}
